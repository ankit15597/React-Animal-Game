create or replace procedure XXABC_PLSQL_PROC
 (errbuf out varchar2, retcode out varchar2)
 is
 
 begin
 
 fnd_file.put_line(fnd_file.output,'Program, ProgramApplID,ProgramShortName,RequestID');
 
 for rec in (select program, program_application_id, program_short_name,
requestor, request_id
from FND_CONC_REQ_SUMMARY_V 
where requestor='OPERATIONS'
and rownum < 100
order by request_id desc)
 loop
 
    dbms_output.put_line(
   rec.program ||','|| rec.program_application_id ||','||
    rec.program_short_name ||',
    '|| rec.request_id);
   fnd_file.put_line(fnd_file.output,
   rec.program ||','|| rec.program_application_id ||','||
    rec.program_short_name ||','|| rec.request_id);
    
 end loop;
 
 
 end XXABC_PLSQL_PROC; 