select program, program_application_id, program_short_name,
requestor, request_id
from FND_CONC_REQ_SUMMARY_V 
where requestor='OPERATIONS'
order by request_id desc; 

declare
 a varchar2(100) ; b varchar2(100); 
begin 
 XXABC_PLSQL_PROC (a,b); 
end; 