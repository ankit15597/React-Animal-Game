SET VERIFY OFF
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;

 select user_id, user_name, creation_date
 from fnd_user;
 
 